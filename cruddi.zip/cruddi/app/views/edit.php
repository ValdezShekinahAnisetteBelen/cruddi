<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"
        integrity="sha384-.." crossorigin="anonymous">
</head>
<style>
.header {
    font-size: 30px;
    background-color: #F964AE; /* Header background color changed to a different pink shade */
    color: #fff; /* Header text color changed to white */
    padding: 15px;
}

.main {
    color: #FF3385; /* Text color changed to pink */
    background-color: #fff; /* Main content background color changed to white */
    padding: 30px;
}
</style>

<body style="background-color: #FF3385;">
    <div class="container mt-5">
        <form action="<?= site_url('edit'); ?>" method="post">
            <input type="hidden" value="<?= $users['id']; ?>" name="id">
            <div class="header">HR Personnel's Information</div>
            <div class="main">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label"><i class="fas fa-user" style="color: #FF3385;"></i> Name</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="username" value="<?= $users['username']; ?>" style="color: #FF3385;">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label"><i class="fas fa-envelope" style="color: #FF3385;"></i> Email address</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="email" value="<?= $users['email']; ?>" style="color: #FF3385;">
                <div id="emailHelp" class="form-text" style="color: #FF3385;">We'll never share your email with anyone else.</div>
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label"><i class="fas fa-user" style="color: #FF3385;"></i> Phone Number</label>
                <input type="phonenumber" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="phonenumber" value="<?= $users['phonenumber']; ?>" style="color: #FF3385;">
                <div id="emailHelp" class="form-text" style="color: #FF3385;"></div>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label"><i class="fas fa-lock" style="color: #FF3385;"></i> Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" name="password"
                    value="<?= $users['password']; ?>" style="color: #FF3385;">
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label"><i class="fas fa-lock" style="color: #FF3385;"></i> Confirm Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" name="cpassword"
                    value="<?= $users['password']; ?>" style="color: #FF3385;">
            </div>
            <button type="submit" class="btn btn-primary" style="background-color: #FF3385;"><i class="fas fa-save" style="color: #fff;"></i> Save Changes</button>
            
            <a href="<?= site_url(''); ?>" class="btn btn-secondary" style="background-color: #FF3385;"><i class="fas fa-arrow-left" style="color: #fff;"></i> Back to Home</a>
        </form>
    </div>
    </div>
</body>

</html>
