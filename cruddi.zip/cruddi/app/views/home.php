<?php defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Welcome to LavaLust</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-.." crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="shortcut icon" href="data:image/x-icon;," type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style type="text/css">
        html {
            margin: 20px;
        }

        body {
            font-size: 15px;
            font-family: Tahoma, sans-serif;
            color: #fff;
            background-color: #ff66b2;
            box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
        }

        a {
            color: #003399;
            background-color: transparent;
            font-weight: normal;
        }

        .header {
            font-size: 30px;
            background-color: #ff3385;
            color: #fff;
            padding: 15px;
        }

        .main {
            color: #000000;
            background-color: #fff;
            padding: 30px;
        }

        /* Button styles */
        .btn-primary {
            background-color: #ff3385;
            border-color: #ff3385;
            color: #fff;
        }

        /* Table styles */
        .table {
            background-color: #fff;
        }

        /* Font Awesome icon color */
        .fa-pink {
            color: #ff3385;
        }
    </style>
</head>
<body>
    <div class="header">HR Personnel's Information</div>
    <div class="main">
        <b>CREATE READ UPDATE DELETE</b>
        <p>Input Your Information below:</p>
        <br><br>
        <div class="container">
            <form action="<?= site_url('insert'); ?>" method="post">
                <div class="mb-3">
                    <label for="username" class="form-label"><i class="fas fa-user fa-pink"></i> Name</label>
                    <input type="text" class="form-control" id="username" aria-describedby="emailHelp" name="username">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label"><i class="fas fa-envelope fa-pink"></i> Email address</label>
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email">
                    <div id="emailHelp" class="form-text"></div>
                </div>
                <div class="mb-3">
                    <label for="phonenumber" class="form-label"><i class="fas fa-user fa-pink"></i> Phone Number</label>
                    <input type="text" class="form-control" id="phonenumber" aria-describedby="emailHelp" name="phonenumber">
                    <div id="emailHelp" class="form-text"></div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label"><i class="fas fa-lock fa-pink"></i> Password</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                <div class="mb-3">
                    <label for="cpassword" class="form-label"><i class="fas fa-lock fa-pink"></i> Confirm Password</label>
                    <input type="password" class="form-control" id="cpassword" name="cpassword">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>

        <div class="container">
            <table id="personnelTable" class="table">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">HR Personnel's Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone Number</th>
                        <th scope="col">Password</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user['id'] ?></td>
                            <td><?= $user['username'] ?></td>
                            <td><?= $user['email'] ?></td>
                            <td><?= $user['phonenumber'] ?></td>
                            <td><?= $user['password'] ?></td>
                            <td>
                                <a href="<?= site_url('delete/' . $user['id']); ?>" type="button" class="btn btn-danger">Delete</a>
                                <a href="<?= site_url('seteditdata/' . $user['id']); ?>" type="button" class="btn btn-primary">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        // Initialize DataTable with pagination
        $('#personnelTable').DataTable({
            "paging": true,  // Enable pagination
            "lengthChange": false, // Disable the option to change the number of records displayed per page
        });
    });
</script>
