<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class User extends Controller {

    public function aboutUs() {
        $data['name'] = "Shekinah";
        $data['age'] = "20";
        $this->call->view('about_us', $data);
    }
    
	public function index() {
        $this->call->view('user_page');
    }

    public function new($name) {
        echo 'Hello, ' . $name;
    }
}
?>
