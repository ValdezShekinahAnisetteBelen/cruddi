<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class User_Controller extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->call->model('User_model');
    }
    public function index()
    {
        $data['users'] = $this->User_model->getUser();
        $this->call->view('home', $data);
    }
    public function insert()
    {

        if ($this->form_validation->submitted()) {
            $this->form_validation
            ->username('username')
                ->required()
                ->min_length(5)
                ->max_length(20)
            ->email('email')
                ->valid_email()
            ->phonenumber('phonenumber')
                ->required()
                ->min_length(10)
            ->password('password')
                ->required()
                ->min_length(8)
            ->cpassword('cpassword')
                ->matches('password')
                ->required()
                ->min_length(8);
            if ($this->form_validation->run()) {
                $username = $this->io->post('username');
                $email = $this->io->post('email');
                $phonenumber = $this->io->post('phonenumber');
                $password = md5($this->io->post('password'));

                $this->User_model->insert($username, $email, $phonenumber, $password);
                redirect('');
            } else {
                echo $this->form_validation->errors();
            }
        }
    }

    public function delete($data)
    {
        $this->User_model->delete($data);
        redirect('');
    }

    public function seteditdata($id)
    {
        $data['users'] = $this->User_model->seteditdata($id);
        $this->call->view('edit', $data);
        //echo $id;
        //var_dump($data['users']);
    }

    public function edit()
    {
        if ($this->form_validation->submitted()) {
            $this->form_validation
                ->id('id')
                ->required()
                ->username('username')
                ->required()
                ->min_length(5)
                ->max_length(20)
                ->name('email')
                ->valid_email()
                ->phonenumber('phonenumber')
                ->required()
                ->min_length(10)
                ->cpassword('cpassword')
                ->matches('password')
                ->required()
                ->min_length(8);
            if ($this->form_validation->run()) {
                $id = $this->io->post('id');
                $username = $this->io->post('username');
                $email = $this->io->post('email');
                $phonenumber = $this->io->post('phonenumber');
                $password = md5($this->io->post('password'));

                // var_dump($username, $email, $password);

                $this->User_model->edit($id, $username, $email, $phonenumber, $password);
                redirect('');
            } else {
                echo $this->form_validation->errors();
            }
        }
    }

}
?>