<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class User_model extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->call->database();

    }

    public function insert($username, $email, $phonenumber, $password)
    {

        $bind = array(
            'username' => $username,
            'email' => $email,
            'phonenumber' => $phonenumber,
            'password' => $password,

        );

        $this->db->table('user')->insert($bind);
    }

    public function getUser()
    {
        $data = $this->db->table('user')->get_all();
        return $data;
    }
    public function delete($data)
    {
        $this->db->table('user')->where("id", $data)->delete();
    }

    public function seteditdata($id)
    {
        $data = $this->db->table('user')->where('id', $id)->get();
        return $data;
    }

    public function edit($id, $username, $email, $phonenumber, $password)
    {
        $data = [
            'id' => $id,
            'username' => $username,
            'email' => $email,
            'phonenumber' => $phonenumber,
            'password' => $password,
        ];

        $this->db->table('user')->where('id', $id)->update($data);
    }

}
?>